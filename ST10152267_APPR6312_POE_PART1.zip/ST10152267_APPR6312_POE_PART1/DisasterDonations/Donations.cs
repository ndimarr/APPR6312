﻿namespace DisasterDonations
{
    using Microsoft.Data.SqlClient;
    using Microsoft.AspNetCore.Http;
    public class Donations
    {
        public string username { get; set; }
        public string password { get; set; }
        
        String connectionString = "Server=tcp:ndimar45.database.windows.net,1433;Initial Catalog=Nonprofit;Persist Security Info=False;User ID=st10152267@rccone.edu.za@ndimar45;Password={JungleO@ts22};MultipleActiveResultSets=False;Encrypt=False;TrustServerCertificate=True;Connection Timeout=30;";

        public void Signup(String Username, String Password)
        {
            username = Username;
            password = Password;

            // Use ADO.NET or an ORM like Entity Framework to insert data into the user_table
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (var command = new SqlCommand("INSERT INTO user_table (username, password_hash) VALUES (@username, @password)", connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", password);

                    command.ExecuteNonQuery();
                }
            }
        }

        public Boolean Login(String Username, String Password)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                Console.Write("Enter username: ");
                string username = Console.ReadLine();

                Console.Write("Enter password: ");
                string password = Console.ReadLine();

                // Query to retrieve user information based on the username
                string query = "SELECT user_id, username, password_hash FROM user_table WHERE username = @username";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            int userId = reader.GetInt32(0);
                            string dbUsername = reader.GetString(1);
                            string dbPasswordHash = reader.GetString(2);

                            // Here, you should use a secure password hashing library to compare passwords
                            // For demonstration purposes, we'll compare plaintext passwords
                            if (password == dbPasswordHash)
                            {
                                Console.WriteLine("Login successful!");
                                Console.WriteLine($"User ID: {userId}");
                                Console.WriteLine($"Username: {dbUsername}");
                                return true;
                            }
                            else
                            {
                                return false;
                            }
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }
        }
    }
}
