using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DisasterDonations.Pages
{
    public class CaptureDonationsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
