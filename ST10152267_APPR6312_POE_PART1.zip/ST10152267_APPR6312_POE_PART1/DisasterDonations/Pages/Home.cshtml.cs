using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DisasterDonations.Pages
{
    public class HomeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
