using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DisasterDonations.Pages
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }

        public void OnPost()
        {
            string name = Request.Form["name"];
            string password = Request.Form["password"];

            Donations don = new Donations();
            if(don.Login(name, password))
            {
                if(don.username.Equals("admin"))
                {
                    RedirectToPage("/adminHome");
                }
                else
                {
                    RedirectToPage("/Home");
                }
            }
            else
            {
                RedirectToPage("/Error");
            }
        }
    }
}
