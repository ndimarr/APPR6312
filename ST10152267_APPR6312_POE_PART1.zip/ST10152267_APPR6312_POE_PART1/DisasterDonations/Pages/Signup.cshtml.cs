using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DisasterDonations.Pages
{
    public class SignupModel : PageModel
    {
        public void OnGet()
        {
        }

        public void OnPost()
        {
            string name = Request.Form["name"];
            string password = Request.Form["password"];

            Donations don = new Donations();
            don.Signup(name, password);
        }
    }
}
