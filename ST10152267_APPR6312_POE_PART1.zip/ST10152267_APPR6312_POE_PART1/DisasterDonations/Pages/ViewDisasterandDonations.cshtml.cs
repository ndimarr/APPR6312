using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DisasterDonations.Pages
{
    public class ViewDisasterandDonationsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
