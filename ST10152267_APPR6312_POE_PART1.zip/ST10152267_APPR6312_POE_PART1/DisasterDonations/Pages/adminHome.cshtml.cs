using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DisasterDonations.Pages
{
    public class adminHomeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
